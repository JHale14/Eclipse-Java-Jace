package pr1;
/*
 * Class: CMSC201
 * Instructor: Dr. Grinberg
 * Description: calculate wind chill
 * Due: 02/2/26
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any student.
 * Jason Hale
 */

import java.util.Scanner;

public class WindChillTemperature {
	public static void main(String[] args) {
	Scanner input = new Scanner(System.in);
	final double FIRST_COEFFICIENT = 35.74;
	final double SECOND_COEFFICIENT = 0.6215;
	final double THIRD_COEFFICIENT = 35.75;
	final double FOURTH_COEFFICIENT = 0.4275;
	System.out.print("Enter the temperature in Fahrenheit between -58F and 41F: ");
	double ta = input.nextDouble();
	System.out.print("Enter the wind speed (>=2) in miles per hour: ");
	double v = input.nextDouble();
	double twc = FIRST_COEFFICIENT + SECOND_COEFFICIENT * ta - THIRD_COEFFICIENT * Math.pow(v, 0.16)
		+ FOURTH_COEFFICIENT * ta * Math.pow(v, 0.16);
	System.out.println("The wind chill index is " + twc);
	
	}
}