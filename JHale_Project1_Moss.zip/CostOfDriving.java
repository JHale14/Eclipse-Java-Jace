package pr1;
/*
 * Class: CMSC201
 * Instructor: Dr. Grinberg
 * Description: calculate cost of driving
 * Due: 02/2/26
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any student.
 * Jason Hale
 */
import java.util.Scanner;
public class CostOfDriving {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter driving distance: ");
		double distance = input.nextDouble();
		System.out.print("Enter miles per gallon: ");
		double miles = input.nextDouble();
		System.out.print("Enter price per gallon: ");
		double price = input.nextDouble();
		double sub = distance / miles;
		double cost = sub * price;
		cost = (int)(cost * 100) / 100.0;
		System.out.println("The cost of driving is $" + cost);
	}

}
